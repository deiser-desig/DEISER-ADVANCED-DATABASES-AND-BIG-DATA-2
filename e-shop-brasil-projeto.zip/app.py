
import streamlit as st
from pymongo import MongoClient
from faker import Faker
import random

st.title("Painel de Gestão - E-Shop Brasil")

client = MongoClient("mongodb://mongodb:27017/")
db = client["eshop"]

fake = Faker()

colecao = st.sidebar.selectbox("Coleção", ["clientes", "pedidos"])

# Inserção
if st.button("Inserir Dado Aleatório"):
    if colecao == "clientes":
        dado = {"nome": fake.name(), "email": fake.email(), "endereco": fake.address()}
    else:
        dado = {"produto": fake.word(), "quantidade": random.randint(1, 10), "valor": round(random.uniform(10, 100), 2)}
    db[colecao].insert_one(dado)
    st.success("Dado inserido!")

# Exibir dados
docs = list(db[colecao].find())
if docs:
    st.write(f"Dados da coleção `{colecao}`:")
    st.dataframe(docs)
